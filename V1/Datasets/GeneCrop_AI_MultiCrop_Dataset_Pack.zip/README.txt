GeneCrop AI Multi-Crop Dataset - Starter Pack

The main CSV is derived from the official ICAR publication:
"Crop Cultivars Developed Through Molecular Breeding, Second Edition" (2022).

The source documents 74 molecular-breeding cultivars across seven crops:
rice, wheat, maize, pearl millet, chickpea, soybean and groundnut.

The CSV contains a verified starter subset across all seven crops with:
crop, variety, genes/QTL, improved trait, reported yield, maturity,
suitability and recommended area.

IMPORTANT:
This is NOT yet the final genotype-environment master table. The
environmental observation fields (location-year weather, soil and
historical yield) still need to be joined using official datasets.
Do not fill those fields with invented values.

Official source:
https://icar.gov.in/sites/default/files/2022-06/Crop-Cultivars-2nd-Edition.pdf

The ICAR publication states that 74 cultivars were released through
molecular breeding across these seven crops and provides details of
genes/QTL, traits, yield, maturity and recommended areas.
